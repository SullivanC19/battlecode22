package qualificationbot_2;

import battlecode.common.GameActionException;
import battlecode.common.RobotType;

public class Laboratory {
    public static void run() throws GameActionException {
        Communication.updateDroidCount();

        int budget = Communication.getBudget();

        int roundNum = Memory.rc.getRoundNum();

        int teamGold = Memory.rc.getTeamGoldAmount(Memory.rc.getTeam());

        if (Memory.rc.canTransmute()
                && teamGold < RobotType.SAGE.buildCostGold) {
            Memory.rc.transmute();
        }
    }
}