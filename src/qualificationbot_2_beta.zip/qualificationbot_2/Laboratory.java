package qualificationbot_2;

import battlecode.common.GameActionException;

public class Laboratory {
    public static void run() throws GameActionException { }
}