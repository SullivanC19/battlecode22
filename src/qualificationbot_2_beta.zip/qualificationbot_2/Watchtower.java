package qualificationbot_2;

import battlecode.common.GameActionException;

public class Watchtower {
    public static void run() throws GameActionException {
//        Memory.update();
//
//        Communication.updateLead();
//
//        RobotInfo closestEnemyRobot = Utils.getClosestEnemyRobot();
//        if (closestEnemyRobot != null && Memory.rc.canAttack(closestEnemyRobot.getLocation())) {
//            Memory.rc.attack(closestEnemyRobot.getLocation());
//        }
    }
}