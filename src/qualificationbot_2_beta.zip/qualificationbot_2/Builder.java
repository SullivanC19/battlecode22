package qualificationbot_2;

import battlecode.common.GameActionException;
import battlecode.common.MapLocation;

public class Builder {
    private static MapLocation targetLeadBlock;

    public static void run() throws GameActionException { }

}
