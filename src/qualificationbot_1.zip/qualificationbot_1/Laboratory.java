package qualificationbot_1;

import battlecode.common.GameActionException;

public class Laboratory {
    public static void run() throws GameActionException { }
}